PROP LUX — package statique (README)
Contenu:
- index.html (landing page dark)
- style.css (styles)
- dashboard.html (demo members area)
- terms.html / privacy.html (templates)
- stripe_integration_instructions.txt (how-to)

But: This is a static demo ready to be hosted for free (GitHub Pages / Netlify / Cloudflare Pages).
To accept REAL payments you MUST:
1) Create a Stripe account (free to create). Get publishable and secret keys.
2) Add a backend or use a payments provider (LemonSqueezy / Paddle) that can create Checkout sessions / handle MoR.
3) Replace the demo checkout flow with server-side session creation. See stripe_integration_instructions.txt

Deploy (free):
- Create a GitHub repo, push these files, enable GitHub Pages (or connect to Netlify/Cloudflare Pages). See online guides (README).

Notes about cost:
- Building and hosting static site: free (GitHub Pages / Netlify free tiers).
- Payment processors charge transaction fees per sale (normal).
- Some providers (LemonSqueezy/Paddle) offer Merchant-of-Record for VAT/fraud handling but take larger fees.
