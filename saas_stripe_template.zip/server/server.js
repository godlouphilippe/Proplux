// server.js
// Example Node/Express server that creates Stripe Checkout Sessions for subscriptions.
// USAGE:
// 1) set environment variable STRIPE_SECRET with your Stripe Secret Key (starts with sk_...)
// 2) npm install
// 3) node server.js
//
// NOTE: This code expects you to install 'stripe' and 'express' packages.
//
const express = require('express');
const Stripe = require('stripe');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(cors());

const stripeSecret = process.env.STRIPE_SECRET;
if (!stripeSecret) {
  console.warn("⚠️ STRIPE_SECRET not set. Create a .env file with STRIPE_SECRET=sk_xxx to enable server Checkout creation.");
}
const stripe = stripeSecret ? Stripe(stripeSecret) : null;

// Simple health route
app.get('/', (req, res) => res.send('SaaS server is running.'));

// Create a Checkout Session for a subscription (replace price ID with your own)
// You must create a recurring Price in the Stripe Dashboard and put its price ID here.
app.post('/create-checkout-session', async (req, res) => {
  try {
    if (!stripe) return res.status(500).json({ error: 'STRIPE_SECRET not configured on server.' });

    // Example: you should replace this with your actual price id for a monthly plan (starts with price_...)
    const priceId = req.body.priceId || process.env.STRIPE_MONTHLY_PRICE_ID || 'price_replace_me';

    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [
        { price: priceId, quantity: 1 }
      ],
      // Adjust success/cancel URLs to your domain
      success_url: (req.headers.origin || 'http://localhost:4242') + '/success.html?session_id={CHECKOUT_SESSION_ID}',
      cancel_url: (req.headers.origin || 'http://localhost:4242') + '/cancel.html',
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 4242;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
