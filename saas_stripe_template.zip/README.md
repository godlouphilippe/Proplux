# Template SaaS avec Stripe Checkout

Ce ZIP contient deux façons simples d'accepter des abonnements mensuels Stripe :

## 1) Version statique (la plus simple)
Le dossier `static/` contient `index.html` — un bouton qui redirige directement vers votre lien Stripe Checkout préconfiguré :
https://buy.stripe.com/5kQ7sM3DJ6CO4nJfqj0ZW04

Il suffit d'héberger ces fichiers (Netlify, Vercel, GitHub Pages, ou n'importe quel hébergement statique) — quand les utilisateurs cliqueront sur le bouton, ils seront redirigés vers Stripe pour payer l'abonnement.

## 2) Version serveur (optionnelle, plus flexible)
Le dossier `server/` contient un exemple de serveur Node/Express (`server.js`) qui montre comment **créer dynamiquement** des sessions Checkout via l'API Stripe.

### Pour utiliser le serveur :
1. Installez Node.js (version 18+ recommandée).
2. Copiez le dossier `server/` sur votre machine ou sur un serveur.
3. Créez un fichier `.env` à la racine du dossier `server/` avec :
```
STRIPE_SECRET=sk_...
STRIPE_MONTHLY_PRICE_ID=price_...
```
> **Ne partagez jamais** votre clé secrète `sk_...`. Utilisez des variables d'environnement.

4. Exécutez :
```bash
npm install
npm start
```

5. Faites un POST vers `POST /create-checkout-session` (ex: depuis votre frontend) pour obtenir l'URL de Checkout et rediriger l'utilisateur.

### Remarques importantes
- Le lien que vous avez fourni (`buy.stripe.com/...`) est un lien Stripe Checkout hébergé. Il est parfaitement valide pour recevoir des abonnements tel quel. La version statique du template utilise directement ce lien.
- Si vous voulez que je intègre des textes/branding/images spécifiques dans `index.html`, ou que je mette en place un plan précis (price ID) dans le serveur, dis-le moi et je mettrai à jour le ZIP.

## Fichiers inclus
- static/index.html
- static/styles.css
- server/server.js
- server/package.json
- server/success.html
- server/cancel.html
- README.md

